package Ex_12_FILA.src;

public class No {
    public String str;
    public No prox;

    public No() {}
    public No(String str) {
        this.str = str;
        this.prox = null;
    }
}
