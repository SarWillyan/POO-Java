package Ex_8_CALENDARIO_ESTATICO.src;

import static Ex_8_CALENDARIO_ESTATICO.src.Calendario.Mostra;

public class Main {
    public static void main(String[] args) {
        Mostra(05, 2022);
    }
}
