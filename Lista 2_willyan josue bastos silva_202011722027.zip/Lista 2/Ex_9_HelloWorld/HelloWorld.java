package Ex_9_HelloWorld;
//package cap01.sec01;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
