package Ex3.src;

public class Main {
    public static void main(String[] args) {
        System.out.println(Sieve.sieveAL(100));
        System.out.println(Sieve.sieveHash(100));
    }
}
