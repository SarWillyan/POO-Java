package Ex1_2_10.src;
public interface Mensuravel {
    double getMedida();
}
